# The-Cake-Fairy
Group NO. : 53
Name1: Mayuresh Chimankar (Roll no.: 22075046)
Name2: Aditya (Roll no.: 22074003)
A cake shop website
Introducing The Cake Fairy - Your One-Stop Online Shop for Delicious Treats and Confectioneries for Any Occasion!
The Cake Fairy cake shop is a python-based framework Django application, creates storefront online cake shop for customers to for variety cakes and flavours for all categories cakes.You can browse and search for cakes by category or individual search . The main goal of the project is to simplify it for who store various cake shop information.
